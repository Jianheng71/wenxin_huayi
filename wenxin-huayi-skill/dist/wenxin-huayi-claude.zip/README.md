# 文心画意 — Claude 部署包

此包包含完整技能指令和适用于 Claude 的部署说明。

## 部署

在 Claude 的 Skills 管理界面选择创建/上传 Skill，将 ZIP 中的 `wenxin-huayi/SKILL.md` 与 `README.md` 放入同一目录后压缩上传。如果当前账号或界面没有 Skills 上传入口，可将 `INSTRUCTIONS.md` 复制到项目指令中使用。

1. 根据平台能力启用联网搜索和图像生成；若没有对应工具，助手应明确说明限制并提供提示词，不可声称已检索或生成图片。
2. 输入“以文为墨，画现乾坤！”并提供主题进行测试。

## 文件

- `INSTRUCTIONS.md`：可粘贴到平台自定义指令中的完整技能说明。
- Claude 包另含 `wenxin-huayi/SKILL.md` 和 `wenxin-huayi/README.md`，用于 Skill 上传。

## 注意

本包不会登录、调用账号 API 或代替用户发布。创建、保存和发布均由用户在平台界面完成；不要将账号密码或 API 密钥填入包内。
